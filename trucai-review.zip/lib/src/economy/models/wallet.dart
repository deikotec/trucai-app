// src/economy/models/wallet.dart
class Wallet {
  final String uid;
  final int balance;
  const Wallet({required this.uid, required this.balance});
}
