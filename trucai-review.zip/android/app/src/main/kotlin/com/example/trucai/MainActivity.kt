package com.example.trucai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
